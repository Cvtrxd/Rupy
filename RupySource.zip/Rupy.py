import sys
import re

DICTIONARY = {
    # Ключевые слова
    r'\bфункция\b': 'def',
    r'\bкласс\b': 'class',
    r'\bесли\b': 'if',
    r'\bиначе_если\b': 'elif',
    r'\bиначе\b': 'else',
    r'\bпока\b': 'while',
    r'\bдля\b': 'for',
    r'\bв\b': 'in',
    r'\bвернуть\b': 'return',
    r'\bвывод\b': 'print',
    r'\bввод\b': 'input',
    r'\bвыход\b': 'break',
    r'\bпропустить\b': 'continue',
    r'\bничего\b': 'pass',
    r'\bутверждать\b': 'assert',
    r'\bудалить\b': 'del',
    r'\bглобальный\b': 'global',
    r'\bнелокальный\b': 'nonlocal',
    r'\bвыдать\b': 'yield',
    r'\bлямбда\b': 'lambda',
    r'\bасинхронный\b': 'async',
    r'\bждать\b': 'await',
    r'\bсовпадение\b': 'match',
    r'\bслучай\b': 'case',

    # Импорты
    r'\bимпорт\b': 'import',
    r'\bиз\b': 'from',
    r'\bкак\b': 'as',

    # Обработка исключений
    r'\bпопробовать\b': 'try',
    r'\bперехватить\b': 'except',
    r'\bнаконец\b': 'finally',
    r'\bподнять\b': 'raise',

    # ООП и Контекст
    r'\bэто\b': 'self',
    r'\bс\b': 'with',

    # Логика и значения
    r'\bи\b': 'and',
    r'\bили\b': 'or',
    r'\bне\b': 'not',
    r'\bявляется\b': 'is',
    r'\bИстина\b': 'True',
    r'\bЛожь\b': 'False',
    r'\bПусто\b': 'None',

    # Встроенные функции и типы
    r'\bдлина\b': 'len',
    r'\bдиапазон\b': 'range',
    r'\bчисло\b': 'int',
    r'\bдробное\b': 'float',
    r'\bстрока\b': 'str',
    r'\bсписок\b': 'list',
    r'\bсловарь\b': 'dict',
    r'\bмножество\b': 'set',
    r'\bкортеж\b': 'tuple',
    r'\bбулево\b': 'bool',
    r'\bтип\b': 'type',
    r'\bсумма\b': 'sum',
    r'\bминимум\b': 'min',
    r'\bмаксимум\b': 'max',
    r'\bабсолютное\b': 'abs',
    r'\bокруглить\b': 'round',
    r'\bсортировать\b': 'sorted',
    r'\bоткрыть\b': 'open',
    r'\bперечислить\b': 'enumerate',
    r'\bобъединить\b': 'zip',
    r'\bвсе\b': 'all',
    r'\bлюбой\b': 'any',
    r'\bпреобразовать\b': 'map',
    r'\bфильтр\b': 'filter',
    r'\bявляется_экземпляром\b': 'isinstance',
    r'\bявляется_подклассом\b': 'issubclass',
    r'\bсимвол\b': 'chr',
    r'\bкод_символа\b': 'ord',
    r'\bсправка\b': 'help',
    r'\bатрибуты\b': 'dir',

    # Исключения / Ошибки
    r'\bИсключение\b': 'Exception',
    r'\bОшибкаЗначения\b': 'ValueError',
    r'\bОшибкаТипа\b': 'TypeError',
    r'\bОшибкаИмени\b': 'NameError',
    r'\bОшибкаИндекса\b': 'IndexError',
    r'\bОшибкаКлюча\b': 'KeyError',
    r'\bОшибкаДеленияНаНоль\b': 'ZeroDivisionError',
    r'\bОшибкаФайлНеНайден\b': 'FileNotFoundError',
    r'\bОшибкаАтрибута\b': 'AttributeError',
    r'\bОшибкаИмпорта\b': 'ImportError',
    r'\bОшибкаМодульНеНайден\b': 'ModuleNotFoundError',
    r'\bПрерываниеКлавиатуры\b': 'KeyboardInterrupt',
    r'\bОшибкаСинтаксиса\b': 'SyntaxError',
    r'\bОшибкаСнега\b': 'RuntimeError',
}

def translate_rupy_to_python(code: str) -> str:
    # Игнорируем строки в кавычках, чтобы не заменить текст внутри print("если ...")
    string_pattern = r'(\".*?\"|\'.*?\')'
    parts = re.split(string_pattern, code, flags=re.DOTALL)

    translated_parts = []
    for part in parts:
        if (part.startswith('"') and part.endswith('"')) or (part.startswith("'") and part.endswith("'")):
            translated_parts.append(part)
        else:
            sub_part = part
            for ru_pattern, py_word in DICTIONARY.items():
                sub_part = re.sub(ru_pattern, py_word, sub_part)
            translated_parts.append(sub_part)

    return "".join(translated_parts)

def main():
    if len(sys.argv) < 2:
        вывод_ошибки = "Использование: rupy <файл.rupy>"
        print(вывод_ошибки)
        return

    filepath = sys.argv[1]

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            rupy_code = f.read()

        py_code = translate_rupy_to_python(rupy_code)
        
        # Выполняем полученный Python-код
        exec(py_code, {'__name__': '__main__'})

    except FileNotFoundError:
        print(f"Ошибка: Файл '{filepath}' не найден.")
    except Exception as e:
        print(f"Ошибка выполнения Rupy: {e}")

if __name__ == "__main__":
    main()